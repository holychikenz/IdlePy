class Crafting:
    def __init__(self):
        pass